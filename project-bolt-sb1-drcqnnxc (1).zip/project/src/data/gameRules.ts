export interface RuleSection {
    title: string;
    steps: string[];
}

export const gameRules: RuleSection[] = [
    {
        title: "Préparation",
        steps: [
            "Choisissez votre pion parmi les personnages célèbres de la francophonie",
            "Placez-le sur la case départ (Paris)",
            "Mélangez les cartes de chaque catégorie",
            "Le plus jeune joueur commence"
        ]
    },
    {
        title: "Tour de jeu",
        steps: [
            "Lancez le dé et avancez votre pion",
            "Selon la case, piochez une carte de la catégorie correspondante",
            "Les autres joueurs vous posent la question",
            "Vous avez 30 secondes pour répondre"
        ]
    },
    {
        title: "Points et Bonus",
        steps: [
            "Bonne réponse = 2 points",
            "Réponse partielle = 1 point",
            "Bonus culture = +1 point supplémentaire",
            "Bonus pays = Rejouez votre tour"
        ]
    },
    {
        title: "Victoire",
        steps: [
            "Premier à atteindre 30 points",
            "OU",
            "Premier à faire le tour complet du plateau",
            "ET répondre correctement à la question finale"
        ]
    }
];