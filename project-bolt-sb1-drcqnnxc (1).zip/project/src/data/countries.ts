export interface Country {
    name: string;
    capital: string;
    funFact: string;
    image: string;
}

export interface Region {
    region: string;
    countries: Country[];
}

export const countries: Region[] = [
    {
        region: "Europe",
        countries: [
            {
                name: "France",
                capital: "Paris",
                funFact: "Le pays compte plus de 1000 variétés de fromages !",
                image: "/countries/france.jpg"
            },
            {
                name: "Belgique",
                capital: "Bruxelles",
                funFact: "Inventeur des frites et du chocolat praliné",
                image: "/countries/belgium.jpg"
            },
            {
                name: "Suisse",
                capital: "Berne",
                funFact: "On y parle 4 langues officielles",
                image: "/countries/switzerland.jpg"
            }
        ]
    },
    {
        region: "Afrique",
        countries: [
            {
                name: "Sénégal",
                capital: "Dakar",
                funFact: "L'île de Gorée est classée au patrimoine mondial de l'UNESCO",
                image: "/countries/senegal.jpg"
            },
            {
                name: "Côte d'Ivoire",
                capital: "Yamoussoukro",
                funFact: "Plus grand exportateur mondial de cacao",
                image: "/countries/ivory-coast.jpg"
            },
            {
                name: "Maroc",
                capital: "Rabat",
                funFact: "Le plus ancien université du monde est à Fès",
                image: "/countries/morocco.jpg"
            }
        ]
    },
    {
        region: "Amérique",
        countries: [
            {
                name: "Canada (Québec)",
                capital: "Québec",
                funFact: "Le sirop d'érable est un symbole national",
                image: "/countries/quebec.jpg"
            },
            {
                name: "Haïti",
                capital: "Port-au-Prince",
                funFact: "Première république noire indépendante",
                image: "/countries/haiti.jpg"
            }
        ]
    }
];