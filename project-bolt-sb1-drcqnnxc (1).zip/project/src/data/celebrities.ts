export interface Celebrity {
    name: string;
    country: string;
    description: string;
    image: string;
}

export interface CelebrityCategory {
    [key: string]: Celebrity[];
}

export const celebrities: CelebrityCategory = {
    "Artistes": [
        {
            name: "Stromae",
            country: "Belgique",
            description: "Auteur-compositeur-interprète belge connu pour ses hits 'Alors On Danse' et 'Formidable'",
            image: "/celebrities/stromae.jpg"
        },
        {
            name: "Céline Dion",
            country: "Canada",
            description: "Chanteuse québécoise mondialement connue, interprète de 'My Heart Will Go On'",
            image: "/celebrities/celine-dion.jpg"
        },
        {
            name: "MC Solaar",
            country: "France",
            description: "Rappeur français pionnier du hip-hop francophone",
            image: "/celebrities/mc-solaar.jpg"
        }
    ],
    "Sportifs": [
        {
            name: "Zinédine Zidane",
            country: "France",
            description: "Légende du football français, champion du monde 1998",
            image: "/celebrities/zidane.jpg"
        },
        {
            name: "Didier Drogba",
            country: "Côte d'Ivoire",
            description: "Footballeur ivoirien, légende de Chelsea",
            image: "/celebrities/drogba.jpg"
        }
    ],
    "Écrivains": [
        {
            name: "Victor Hugo",
            country: "France",
            description: "Auteur des Misérables et de Notre-Dame de Paris",
            image: "/celebrities/hugo.jpg"
        },
        {
            name: "Léopold Sédar Senghor",
            country: "Sénégal",
            description: "Poète, écrivain et homme politique sénégalais",
            image: "/celebrities/senghor.jpg"
        }
    ]
};